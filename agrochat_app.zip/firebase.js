import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: 'TVŮJ_API_KEY',
  authDomain: 'TVŮJ_PROJECT.firebaseapp.com',
  projectId: 'TVŮJ_PROJECT_ID',
  storageBucket: 'TVŮJ_PROJECT.appspot.com',
  messagingSenderId: 'TVŮJ_SENDER_ID',
  appId: 'TVŮJ_APP_ID'
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
