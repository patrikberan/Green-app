import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet, Alert } from 'react-native';
import { auth, db } from '../firebase';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';

export default function RegisterScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [ico, setIco] = useState('');
  const [dic, setDic] = useState('');

  const handleRegister = async () => {
    try {
      const userCred = await createUserWithEmailAndPassword(auth, email, password);
      await setDoc(doc(db, 'users', userCred.user.uid), {
        name,
        email,
        ico,
        dic
      });
      Alert.alert('Registrace úspěšná');
      navigation.navigate('Login');
    } catch (error) {
      Alert.alert('Chyba', error.message);
    }
  };

  return (
    <View style={styles.container}>
      <TextInput placeholder="Jméno" value={name} onChangeText={setName} style={styles.input} />
      <TextInput placeholder="IČO" value={ico} onChangeText={setIco} style={styles.input} />
      <TextInput placeholder="DIČ" value={dic} onChangeText={setDic} style={styles.input} />
      <TextInput placeholder="Email" value={email} onChangeText={setEmail} style={styles.input} />
      <TextInput placeholder="Heslo" secureTextEntry value={password} onChangeText={setPassword} style={styles.input} />
      <Button title="Registrovat se" onPress={handleRegister} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20 },
  input: { borderBottomWidth: 1, marginBottom: 12, padding: 8 }
});
