import React, { useState } from 'react';
import { View, TextInput, Button, Image, StyleSheet } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { db, storage, auth } from '../firebase';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { collection, addDoc } from 'firebase/firestore';
import uuid from 'react-native-uuid';

export default function OfferScreen() {
  const [description, setDescription] = useState('');
  const [image, setImage] = useState(null);

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images });
    if (!result.canceled) setImage(result.assets[0].uri);
  };

  const uploadOffer = async () => {
    if (!image || !description) return;

    const response = await fetch(image);
    const blob = await response.blob();
    const imageRef = ref(storage, `offers/${uuid.v4()}.jpg`);
    await uploadBytes(imageRef, blob);
    const imageUrl = await getDownloadURL(imageRef);

    await addDoc(collection(db, 'offers'), {
      userId: auth.currentUser.uid,
      description,
      imageUrl,
      createdAt: new Date()
    });

    setDescription('');
    setImage(null);
  };

  return (
    <View style={styles.container}>
      <Button title="Vybrat obrázek" onPress={pickImage} />
      {image && <Image source={{ uri: image }} style={{ width: 200, height: 200 }} />}
      <TextInput
        placeholder="Popis nabídky"
        value={description}
        onChangeText={setDescription}
        style={styles.input}
      />
      <Button title="Přidat nabídku" onPress={uploadOffer} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20 },
  input: { borderBottomWidth: 1, marginTop: 10, marginBottom: 12, padding: 8 }
});
