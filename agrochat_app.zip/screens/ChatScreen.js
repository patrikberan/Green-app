import React, { useState, useEffect } from 'react';
import { View, TextInput, Button, FlatList, Text, StyleSheet } from 'react-native';
import { db, auth } from '../firebase';
import { collection, addDoc, onSnapshot, query, orderBy } from 'firebase/firestore';

export default function ChatScreen() {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');

  useEffect(() => {
    const q = query(collection(db, 'chats'), orderBy('createdAt'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setMessages(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    return unsubscribe;
  }, []);

  const sendMessage = async () => {
    if (text.trim() === '') return;
    await addDoc(collection(db, 'chats'), {
      text,
      sender: auth.currentUser.email,
      createdAt: new Date()
    });
    setText('');
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={messages}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <Text style={styles.message}>{item.sender}: {item.text}</Text>
        )}
      />
      <TextInput value={text} onChangeText={setText} placeholder="Napiš zprávu" style={styles.input} />
      <Button title="Odeslat" onPress={sendMessage} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  message: { marginVertical: 4 },
  input: { borderBottomWidth: 1, marginBottom: 8, padding: 8 }
});
